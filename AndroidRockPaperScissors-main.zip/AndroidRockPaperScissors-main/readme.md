# Rock, Paper, Scissors
This is a simple take on the traditional Rock, Paper, Scissors game made in the form of an Adnroid app programmed in Java. This was one of the first applications that I made in Java and in Android Studio, so my code it a little bit green. I certianly could return to it and update the code, but I think it is a good reference to have some of my early days of programming documented. 

The program allows you to:
- Play against a computer opponent
- Keep Score



---
## Background
Created the project for Ridgewater Colleges Introduction to Java class. This was one of the first programs that we were set free to make as long as it was a rock paper scissors game. The requirments were prettly loose so I added graphics and fonts to "spruce it up a bit".

